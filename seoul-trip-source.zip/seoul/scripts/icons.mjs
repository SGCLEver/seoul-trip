// The checked-in PNGs can be regenerated with @napi-rs/canvas.
import fs from 'node:fs';
const { createCanvas } = await import(process.env.SEOUL_CANVAS_MODULE || '@napi-rs/canvas');
for (const [size, name] of [[192, 'icon-192'], [512, 'icon-512'], [180, 'apple-touch-icon']]) {
  const canvas = createCanvas(size, size);
  const ctx = canvas.getContext('2d');
  ctx.scale(size / 160, size / 160);
  ctx.fillStyle = '#173e39';
  ctx.fillRect(0, 0, 160, 160);
  ctx.strokeStyle = '#7bb8b1';
  ctx.lineWidth = 6;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(33, 108);
  ctx.bezierCurveTo(59, 123, 77, 90, 102, 108);
  ctx.bezierCurveTo(113, 116, 123, 116, 128, 112);
  ctx.stroke();
  ctx.strokeStyle = '#faf7ea';
  ctx.lineWidth = 7;
  ctx.beginPath();
  ctx.moveTo(80, 35);
  ctx.lineTo(80, 91);
  ctx.moveTo(64, 64);
  ctx.lineTo(96, 64);
  ctx.moveTo(70, 48);
  ctx.lineTo(90, 48);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(115, 44, 9, 0, Math.PI * 2);
  ctx.fillStyle = '#f3ae66';
  ctx.fill();
  fs.writeFileSync(new URL('../public/' + name + '.png', import.meta.url), canvas.toBuffer('image/png'));
}

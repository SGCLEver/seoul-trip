"""Import the map rows in the trip brief. Pass the source Markdown path."""
import json
import re
import sys
from pathlib import Path

source = Path(sys.argv[1]).read_text()
rows = source.split("<!-- MAP_ROWS_START -->")[1].split("<!-- MAP_ROWS_END -->")[0]
places = []
for line in rows.splitlines():
    if not line.startswith("| `"):
        continue
    key, name, address, coords, info, links = [item.strip() for item in line.strip("|").split("|")]
    ru, ko = name.split(" · ", 1)
    addresses = address.split(" · ", 1) if " · " in address else ["", ""]
    refs = dict(re.findall(r"\[([^\]]+)\]\(([^\s]+)\)", links))
    info = info.replace("Покажи в списке желаний с пометкой «Закрыто».", "").strip()
    places.append({
        "id": key.strip("`"), "name": ru, "ko": ko if ko != "—" else "",
        "addressKo": addresses[0], "addressLatin": addresses[1],
        "coords": [float(n) for n in coords.split(",")] if coords != "—" else None,
        "info": info, "maps": {"naver": refs.pop("NAVER", ""), "google": refs.pop("Google", "")},
        "sources": [{"name": label, "url": url} for label, url in refs.items()],
        "sourceDate": "2026-11-24"
    })
(Path(__file__).resolve().parents[1] / "src" / "places.json").write_text(
    json.dumps(places, ensure_ascii=False, indent=2) + "\n"
)

import { createHash } from 'node:crypto';
import { readdir, readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = resolve('dist');
const paths = (await readdir(root, { recursive: true, withFileTypes: true }))
  .filter(entry => entry.isFile())
  .map(entry => resolve(entry.parentPath, entry.name).slice(root.length + 1).replaceAll('\\', '/'))
  .filter(path => path !== 'offline-index.json' && path !== 'sw.js').sort();
if (!paths.some(path => /^assets\/seoul-[\w-]+\.pmtiles$/.test(path))) {
  throw new Error('Missing the fingerprinted PMTiles archive. See README for creating the offline map.');
}
const version = createHash('sha256');
const assets = [];
let bytes = 0;
for (const path of paths) {
  const body = await readFile(resolve(root, path));
  version.update(path).update(body);
  assets.push({ path, bytes: body.length, ...(path.endsWith('.pmtiles') ? { shared: true } : {}) });
  bytes += body.length;
}
const index = { version: version.digest('hex').slice(0, 16), bytes, assets };
await writeFile(resolve(root, 'offline-index.json'), JSON.stringify(index, null, 2) + '\n');
console.log(`Offline package: ${(bytes / 1e6).toFixed(1)} MB, ${assets.length} files.`);

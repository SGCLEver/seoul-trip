#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
source_url="${SEOUL_OSM_SOURCE:-https://data.source.coop/protomaps/openstreetmap/v4.pmtiles}"
pmtiles_bin="${SEOUL_PMTILES_BIN:-pmtiles}"
scratch="$(mktemp -d)"
trap 'rm -rf "$scratch"' EXIT
"$pmtiles_bin" extract "$source_url" "$scratch/overview.pmtiles" --bbox=126.30,37.10,127.27,37.83 --minzoom=8 --maxzoom=10 --quiet
"$pmtiles_bin" extract "$source_url" "$scratch/street.pmtiles" --region="$root/map-data/street-areas.geojson" --minzoom=11 --maxzoom=12 --quiet
"$pmtiles_bin" extract "$source_url" "$scratch/nearby.pmtiles" --region="$root/map-data/nearby-areas.geojson" --minzoom=13 --maxzoom=13 --quiet
"$pmtiles_bin" extract "$source_url" "$scratch/details.pmtiles" --region="$root/map-data/detail-areas.geojson" --minzoom=14 --maxzoom=14 --quiet
"$pmtiles_bin" merge "$scratch/overview.pmtiles" "$scratch/street.pmtiles" "$scratch/nearby.pmtiles" "$scratch/details.pmtiles" "$scratch/seoul.pmtiles" --quiet
"$pmtiles_bin" verify "$scratch/seoul.pmtiles"
mv "$scratch/seoul.pmtiles" "$root/map-data/seoul.pmtiles"

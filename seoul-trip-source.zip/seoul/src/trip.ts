import rawPlaces from './places.json';
import placeDetails from './place-details.json';

export type Coords = [number, number];
export type Priority = 'group' | 'want' | 'option' | 'reserve';
type Mode = 'transfer' | 'walk' | 'metro' | 'bus' | 'cable';
type Hours = { text: string; last?: string; shop?: string; ticket?: string; dates?: string[] };
type Details = {
  en?: string; aliases?: string[]; kind?: string; parent?: string; approach?: string;
  hours?: Hours[]; booking?: string; closed?: string; verified?: string;
};
export type Place = Details & {
  id: string; name: string; ko: string; addressKo: string; addressLatin: string;
  coords: Coords | null; info: string; maps: { naver: string; google: string };
  sources: { name: string; url: string }[]; sourceDate: string;
};
export type Event = {
  id: string; placeId?: string; title: string; start: string | null; end: string | null;
  mode?: Mode; note?: string;
};
export type Outing = {
  id: string; title: string; priority: Exclude<Priority, 'group'>; stops: string[];
  condition: string; steps: { mode: Mode; text: string }[]; recommendation?: string;
  dependsOn?: string;
};
export type Day = { date: string; tour: number; label: string; theme: string; events: Event[]; outings: Outing[] };

export const dates = ['2027-02-22', '2027-02-23', '2027-02-24', '2027-02-25', '2027-02-26', '2027-02-27'];
export const PROGRAM_DATE = '24.11.2026';
export const priorities: Record<Priority, string> = { group: 'Группа', want: 'Хочу', option: 'Опция', reserve: 'Запасной' };
export const modes: Record<Mode, string> = {
  transfer: 'Трансфер группы', walk: 'Пешком', metro: 'Метро', bus: 'Автобус', cable: 'Канатная дорога'
};
export const places: Place[] = rawPlaces.map(row => ({
  ...row, coords: row.coords ? [row.coords[0], row.coords[1]] : null,
  ...(placeDetails as Record<string, Details>)[row.id]
}));
export const byId = new Map(places.map(place => [place.id, place]));
const event = (id: string, title: string, placeId?: string, mode?: Mode, note?: string): Event =>
  ({ id, title, placeId, mode, note, start: null, end: null });
const step = (mode: Mode, text: string) => ({ mode, text });

const namsan: Outing = {
  id: 'namsan', title: 'Намсан и замок на Love Tree', priority: 'want', stops: ['namsan-cable', 'n-seoul-tower', 'love-locks'],
  condition: '22 февраля, если NANTA закончится достаточно рано. Запасные вечера: 23 и 26 февраля.',
  dependsOn: 'd2-nanta',
  steps: [
    step('walk', 'Из Мёндона к нижней станции. От Myeong-dong, линия 4, выход 3, дальше пешком в гору.'),
    step('cable', 'До площади у башни. Перед подъёмом проверь ветер и время последнего спуска.'),
    step('bus', 'Альтернатива: Chungmuro, линии 3/4, выход 2, автобус 01A к башне.'),
    step('walk', 'Купить замок в N Gift (Plaza 1F), написать имена и повесить его на Love Tree на площади.'),
    step('bus', 'Спуститься к метро автобусом или канатной дорогой. Последний автобус на дату поездки пока не подтверждён.')
  ],
  recommendation: 'За вход на смотровую башни платят отдельно. Для замка достаточно подняться на площадь.'
};
const palace: Outing = {
  id: 'palace-evening', title: 'Дворцовый музей и K-Heritage', priority: 'want', stops: ['palace-museum', 'folk-museum'],
  condition: '23 февраля, если освободишься до 16:30. Дворцовый музей открыт до 17:30, вход и магазин до 17:00 по обычному графику.',
  dependsOn: 'd3-free',
  steps: [step('walk', 'К выходу 5 станции Gyeongbokgung. Фольклорный музей находится с другой стороны дворца, вход с Samcheong-ro.')],
  recommendation: 'Если группу отпустят поздно, оставь этот вечер под Намсан.'
};
const museum: Outing = {
  id: 'national-evening', title: 'Национальный музей Кореи и магазин № 1', priority: 'want', stops: ['national-museum', 'palace-museum'],
  condition: 'Из Хондэ заложи 30–50 минут и постарайся прийти к 19:30. В среду музей и магазин работают до 21:00, вход до 20:30.',
  dependsOn: 'd4-hongdae',
  steps: [step('metro', 'Hongik Univ. → Ichon на Gyeongui–Jungang в сторону Yongsan. Проверь, что поезд идёт до Ichon.'),
    step('walk', 'Из Ichon через переход Museum Nadeulgil у выходов 1/2.')],
  recommendation: 'Выбери один музей. Для дворцового 24 февраля действует обычный график последней среды: до 21:00, K-Heritage до 20:30.'
};
const seokchon: Outing = {
  id: 'seokchon', title: 'Озеро Сокчхон', priority: 'option', stops: ['seokchon-lake'],
  condition: 'После SEOUL SKY, если есть время до трансфера. 5–10 минут до берега плюс время на прогулку.',
  dependsOn: 'd4-sky',
  steps: [step('walk', 'От Lotte World Tower к северному берегу восточной части озера, Songpa Naru Park.')]
};
const shopping: Outing = {
  id: 'hongdae-shopping', title: 'ADER ERROR и Apple в Хондэ', priority: 'want', stops: ['ader-hongdae', 'apple-hongdae'],
  condition: 'Перед отъездом в музей, если есть запас времени. При позднем освобождении можно остаться в Хондэ.',
  dependsOn: 'd4-hongdae',
  steps: [step('walk', 'От Hongik Univ., выход 9, к ADER ERROR и Apple Hongdae.')],
  recommendation: 'Apple Myeongdong можно посетить 22 февраля. Наличие аксессуаров зависит от магазина.'
};
const apple: Outing = {
  id: 'apple-myeongdong', title: 'Apple Myeongdong', priority: 'reserve', stops: ['apple-myeongdong'],
  condition: 'Если останется время в Мёндоне.', dependsOn: 'd2-myeongdong',
  steps: [step('walk', 'Ориентир — Euljiro 1-ga, линия 2.')]
};
const dosan: Outing = {
  id: 'dosan', title: 'NUDAKE у Dosan Park', priority: 'want', stops: ['nudake-dosan'],
  condition: 'Короткая остановка у Motorstudio или отдельный вариант после COEX. Обычные часы 11:00–21:00.',
  dependsOn: 'd5-motorstudio',
  steps: [step('walk', 'От Hyundai Motorstudio Seoul можно дойти пешком.'),
    step('metro', 'Из COEX: Bongeunsa (линия 9) → Seonjeongneung → Apgujeong Rodeo (Suin–Bundang), выход 5.')]
};
const seongsu: Outing = {
  id: 'seongsu', title: 'Point of View и NUDAKE в Сонсу', priority: 'option', stops: ['point-of-view-seongsu', 'nudake-teahouse', 'point-of-view-yeouido'],
  condition: 'Выйти из COEX желательно к 18:30–18:45. Сначала Point of View, он закрывается раньше.',
  dependsOn: 'd5-library',
  steps: [step('metro', 'Samseong → Seongsu на линии 2 через Jamsil, выход 4.'),
    step('walk', 'После Point of View пройти до NUDAKE TEAHOUSE в Haus Nowhere Seoul (5F).')],
  recommendation: 'У Point of View бывает один выходной в месяц. Запасной филиал находится в The Hyundai Seoul, B2.'
};
const backupPov: Outing = {
  id: 'pov-reserve', title: 'Point of View, запасной вечер', priority: 'reserve', stops: ['point-of-view-seongsu', 'point-of-view-yeouido'],
  condition: 'После возвращения из Йонъина, если успеваешь до 20:00 в Сонсу или до 20:30 в пятницу в Ёыйдо.',
  dependsOn: 'd6-free',
  steps: [step('metro', 'Seongsu, выход 4, или Yeouido, выход 3, по переходу на B2 The Hyundai Seoul.')]
};

export const days: Day[] = [
  { date: dates[0], tour: 2, label: 'Пн', theme: 'Мёндон и Намсан', events: [
    event('d2-arrival', 'Прилёт в Инчхон', undefined, undefined, 'Номер рейса и терминал уточняются.'),
    event('d2-transfer', 'Встреча и трансфер в Сеул', undefined, 'transfer', 'Точку встречи сообщит организатор.'),
    event('d2-hotel', 'Раннее заселение и отдых', 'hotel'),
    event('d2-myeongdong', 'Прогулка по Мёндону', 'myeongdong', undefined, 'Хотток, картофельная спираль и сувениры.'),
    event('d2-kimchi', 'Мастер-класс по кимчи', 'kimchi', undefined, 'Приготовление кимчи и дегустация блинчиков с кимчи.'),
    event('d2-nanta', 'Шоу NANTA', 'nanta-myeongdong', undefined, 'Театр в Мёндоне — вероятная площадка. Сеанс и место подтвердит организатор.')
  ], outings: [namsan, apple] },
  { date: dates[1], tour: 3, label: 'Вт', theme: 'Дворцы и старый Сеул', events: [
    event('d3-square', 'Площадь Кванхвамун', 'gwanghwamun-square'),
    event('d3-palace', 'Дворец Чхандоккун', 'changdeokgung', undefined, 'Во вторник 23.02 Кёнбоккун закрыт по обычному графику.'),
    event('d3-bukchon', 'Букчхон', 'bukchon'),
    event('d3-insadong', 'Инсадон', 'insadong'),
    event('d3-jogyesa', 'Храм Чогеса', 'jogyesa'),
    event('d3-stream', 'Ручей Чонгечон', 'cheonggye-plaza'),
    event('d3-free', 'Свободное время')
  ], outings: [palace, { ...namsan, id: 'namsan-23', priority: 'reserve', dependsOn: 'd3-free' }] },
  { date: dates[2], tour: 4, label: 'Ср', theme: 'SEOUL SKY и Хондэ', events: [
    event('d4-sky', 'Смотровая SEOUL SKY', 'seoul-sky', undefined, 'Стеклянный пол Sky Deck на 118-м этаже. Внешний Sky Bridge закрыт на даты поездки.'),
    event('d4-ddp', 'Трансфер к DDP', 'ddp', 'transfer'),
    event('d4-shopping', 'Шопинг в Тондэмуне', 'dongdaemun-shopping'),
    event('d4-market', 'Рынок Кванджан', 'gwangjang'),
    event('d4-hongdae', 'Трансфер в Хондэ', 'hongdae', 'transfer'),
    event('d4-free', 'Возвращение в отель или свободный вечер', 'hotel')
  ], outings: [seokchon, museum, shopping] },
  { date: dates[3], tour: 5, label: 'Чт', theme: 'Ёнсе и Каннам', events: [
    event('d5-breakfast', 'Завтрак'),
    event('d5-yonsei', 'Университет Ёнсе, кампус Sinchon', 'yonsei', undefined, 'Экскурсия примерно 45–50 минут. Точку встречи сообщит организатор.'),
    event('d5-motorstudio', 'Hyundai Motorstudio Seoul', 'hyundai-motorstudio', undefined, 'Формат посещения уточняется.'),
    event('d5-coex', 'COEX', 'coex'),
    event('d5-library', 'Библиотека Starfield', 'starfield-library'),
    event('d5-free', 'Возвращение в отель или свободный вечер', 'hotel')
  ], outings: [dosan, seongsu] },
  { date: dates[4], tour: 6, label: 'Пт', theme: 'Йонъин', events: [
    event('d6-village', 'Корейская фольклорная деревня', 'korean-folk-village', 'transfer', 'Зимние выступления и традиционную стрельбу из лука уточнит организатор.'),
    event('d6-outlet', 'Lotte Premium Outlets Giheung', 'lotte-giheung', 'transfer'),
    event('d6-free', 'Свободное время', undefined, undefined, 'Время возвращения из Йонъина уточняется.')
  ], outings: [{ ...namsan, id: 'namsan-26', priority: 'reserve', dependsOn: 'd6-free' }, backupPov] },
  { date: dates[5], tour: 7, label: 'Сб', theme: 'Возвращение домой', events: [
    event('d7-breakfast', 'Завтрак'),
    event('d7-checkout', 'Выписка из отеля', 'hotel'),
    event('d7-transfer', 'Трансфер в Инчхон', undefined, 'transfer'),
    event('d7-departure', 'Вылет', undefined, undefined, 'Оставь время на трансфер, регистрацию и контроль.')
  ], outings: [] }
];
export const outings = new Map(days.flatMap(day => day.outings.map(outing => [outing.id, outing] as const)));
export const checklist = [
  ['shoes', 'Удобные кроссовки'], ['layers', 'Тёплые слои для вечернего Намсана'],
  ['battery', 'Зарядить телефон и внешний аккумулятор'], ['offline', 'Скачать карту и открыть её в авиарежиме'],
  ['lock', 'Купить замок в N Gift'], ['names', 'Написать имена'], ['tree', 'Повесить замок на Love Tree']
] as const;
export const packingSuggestions = [
  'Проверить загранпаспорт и правила въезда',
  'Получить от организатора рейсы, терминал и адрес отеля',
  'Проверить страховку для Кореи и Узбекистана',
  'Сохранить билеты и контакты организатора офлайн',
  'Подготовить оплату и наличные воны',
  'Выбрать SIM, eSIM или роуминг',
  'Сверить правила провоза пауэрбанка',
  'Проверить прогноз на дни поездки'
] as const;

export function seoulDate(now = new Date()): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Seoul', year: 'numeric', month: '2-digit', day: '2-digit'
  }).formatToParts(now);
  const get = (key: string) => parts.find(part => part.type === key)?.value;
  return [get('year'), get('month'), get('day')].join('-');
}

import { dates, type Coords } from './trip';

export const settingsFields = [
  ['hotel', 'Название отеля'], ['hotelKo', 'Корейский адрес'], ['station', 'Ближайшая станция и выход'],
  ['lat', 'Широта'], ['lng', 'Долгота'], ['arrivalFlight', 'Рейс прилёта'], ['arrivalTerminal', 'Терминал прилёта'],
  ['departureFlight', 'Рейс вылета'], ['departureTerminal', 'Терминал вылета'],
  ['arrivalMeeting', 'Время и место встречи в ICN'], ['departureMeeting', 'Время встречи перед трансфером'],
  ['notes', 'Заметки']
] as const;
type Field = typeof settingsFields[number][0];
export type Settings = Record<Field, string>;
export type PersonalVisit = {
  id: string;
  date: string;
  time: string;
  note: string;
  place: { placeId: string } | { name: string; address: string; coords: Coords | null };
};
export type PackingItem = { id: string; text: string };
export const packingTextLimit = 140;
export type LocalState = {
  settings: Settings; visited: Record<string, boolean>; checked: Record<string, boolean>;
  moved: Record<string, string>; startAtHotel: boolean; visits: PersonalVisit[]; lastDay: string;
  packing: PackingItem[];
};
const STORAGE_KEY = 'seoul-trip-v1';
const fresh = (): LocalState => ({
  settings: Object.fromEntries(settingsFields.map(([key]) => [key, ''])) as Settings,
  visited: {}, checked: {}, moved: {}, startAtHotel: false, visits: [], lastDay: '', packing: []
});

function object(value: unknown): Record<string, unknown> {
  return value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : {};
}

function isCoords(input: unknown): input is Coords {
  return Array.isArray(input) && input.length === 2 &&
    input.every(value => typeof value === 'number' && Number.isFinite(value)) &&
    Math.abs(input[0]) <= 90 && Math.abs(input[1]) <= 180;
}

export function parseCoords(text: string): Coords | null {
  const match = /^\s*([-+]?\d+(?:[.,]\d+)?)\s*[,; ]\s*([-+]?\d+(?:[.,]\d+)?)\s*$/.exec(text);
  const pair = match?.slice(1).map(value => Number(value.replace(',', '.')));
  return isCoords(pair) ? pair : null;
}

export const isVisitTime = (time: string) => /^(?:[01]\d|2[0-3]):[0-5]\d$/.test(time);

function readVisit(value: unknown): PersonalVisit | null {
  const { id, date, time, note, place } = object(value);
  if (typeof id !== 'string' || !/^visit-[a-z0-9-]+$/.test(id) ||
    typeof date !== 'string' || !dates.includes(date)) return null;
  const fields = object(place);
  const entry = { id, date, time: typeof time === 'string' && isVisitTime(time) ? time : '',
    note: typeof note === 'string' ? note.slice(0, 800) : '' };
  if (typeof fields.placeId === 'string' && /^[a-z0-9-]+$/.test(fields.placeId)) {
    return { ...entry, place: { placeId: fields.placeId } };
  }
  if (typeof fields.name !== 'string' || !fields.name.trim()) return null;
  return { ...entry, place: {
    name: fields.name.trim().slice(0, 120),
    address: typeof fields.address === 'string' ? fields.address.slice(0, 240) : '',
    coords: isCoords(fields.coords) ? fields.coords : null
  } };
}

export function parseBackup(value: unknown): LocalState {
  const input = object(value);
  if (input.version !== 1) throw new Error('Нужен JSON, экспортированный из приложения «Сеул».');
  const data = object(input.data);
  if (!data.settings || !data.visited || !data.checked || !data.moved) {
    throw new Error('В файле отсутствуют настройки или отметки.');
  }
  const cleaned = fresh();
  const settings = object(data.settings);
  for (const [key] of settingsFields) {
    if (typeof settings[key] === 'string') cleaned.settings[key] = settings[key].slice(0, 10000);
  }
  for (const name of ['visited', 'checked'] as const) {
    cleaned[name] = Object.fromEntries(Object.entries(object(data[name])).filter(([key, value]) =>
      /^[a-z0-9-]+$/.test(key) && typeof value === 'boolean')) as Record<string, boolean>;
  }
  cleaned.moved = Object.fromEntries(Object.entries(object(data.moved)).filter(([key, value]) =>
    /^[a-z0-9-]+$/.test(key) && typeof value === 'string' && dates.includes(value))) as Record<string, string>;
  cleaned.startAtHotel = data.startAtHotel === true;
  if (typeof data.lastDay === 'string' && dates.includes(data.lastDay)) cleaned.lastDay = data.lastDay;
  if (Array.isArray(data.visits)) {
    const visits = data.visits.slice(0, 300).map(readVisit).filter(visit => visit !== null);
    cleaned.visits = [...new Map(visits.map(visit => [visit.id, visit])).values()];
  }
  if (Array.isArray(data.packing)) {
    const items = new Map<string, PackingItem>();
    for (const item of data.packing) {
      const { id, text } = object(item);
      if (typeof id !== 'string' || !/^pack-[a-z0-9-]+$/.test(id) || typeof text !== 'string') continue;
      const name = text.trim().slice(0, packingTextLimit);
      if (name) items.set(id, { id, text: name });
    }
    cleaned.packing = [...items.values()];
  }
  return cleaned;
}

export function readState(): LocalState {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? parseBackup(JSON.parse(saved)) : fresh();
  } catch {
    return fresh();
  }
}
export function saveState(data: LocalState): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify({ version: 1, data }));
}
export function hotelCoords(settings: Settings): Coords | null {
  if (!settings.lat.trim() || !settings.lng.trim()) return null;
  const lat = Number(settings.lat.replace(',', '.'));
  const lng = Number(settings.lng.replace(',', '.'));
  return Number.isFinite(lat) && Number.isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180
    ? [lat, lng] : null;
}

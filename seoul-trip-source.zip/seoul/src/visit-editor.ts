import { dates, days, type Coords, type Place } from './trip';
import { isVisitTime, parseCoords, type PersonalVisit } from './storage';
import { escape, matchesPlace, short } from './text';

type EditorOptions = {
  places: () => Place[];
  save: (visit: PersonalVisit) => void;
  remove: (visit: PersonalVisit) => void;
  pick: () => void;
};

export class VisitEditor {
  private visit?: PersonalVisit;
  private chosen?: Place;
  private form!: HTMLFormElement;

  constructor(private dialog: HTMLDialogElement, private options: EditorOptions) {
    dialog.addEventListener('click', event => {
      const button = (event.target as HTMLElement).closest('button');
      if (!button) return;
      const choose = button.dataset.choose;
      if (choose) {
        this.chosen = this.options.places().find(place => place.id === choose);
        this.renderChoice();
        this.form.querySelector<HTMLElement>('[name="date"]')?.focus();
        return;
      }
      switch (button.dataset.editor) {
        case 'close': this.dialog.close(); break;
        case 'own':
          this.chosen = undefined;
          this.renderChoice();
          this.form.querySelector<HTMLElement>('[name="name"]')?.focus();
          break;
        case 'pick': this.dialog.close(); this.options.pick(); break;
        case 'remove':
          if (this.visit && confirm('Убрать этот визит из личного плана?')) {
            this.dialog.close();
            this.options.remove(this.visit);
          }
          break;
      }
    });
    dialog.addEventListener('input', event => {
      if ((event.target as HTMLElement).id === 'visit-search') this.renderMatches();
    });
    dialog.addEventListener('submit', event => {
      event.preventDefault();
      this.save();
    });
  }

  open(date: string, visit?: PersonalVisit, selected?: Place) {
    this.visit = visit;
    const own = visit?.place && 'name' in visit.place ? visit.place : undefined;
    const placeId = visit?.place && 'placeId' in visit.place ? visit.place.placeId : undefined;
    this.chosen = selected ?? (placeId ? this.options.places().find(place => place.id === placeId) : undefined);
    this.dialog.innerHTML = `<form class="visit-form">
      <div class="visit-editor-head">
        <h2 id="visit-editor-title">${visit ? 'Изменить визит' : 'Добавить место'}</h2>
        <button type="button" class="close-sheet" data-editor="close" aria-label="Закрыть редактор">×</button>
      </div>
      <div class="editor-choice"></div>
      <div class="editor-search">
        <label for="visit-search">Название места</label>
        <input type="search" id="visit-search" name="name" maxlength="120" value="${escape(own?.name)}"
          placeholder="Поиск или новое название" autocomplete="off">
        <div id="visit-matches"></div>
      </div>
      <div class="editor-own">
        <label>Адрес<input name="address" maxlength="240" value="${escape(own?.address)}" placeholder="Можно на корейском"></label>
        <label>Координаты<input name="coords" value="${escape(own?.coords?.join(', '))}" placeholder="37.56654, 126.97802"></label>
        <button class="action-link" type="button" data-editor="pick">Поставить точку на карте</button>
      </div>
      <div class="editor-date">
        <label>День<select name="date" aria-label="День визита">${days.map(day => `<option value="${day.date}" ${day.date === (visit?.date || date) ? 'selected' : ''}>${day.label}, ${short(day.date)}</option>`).join('')}</select></label>
        <label>Время по Сеулу <input name="time" type="time" value="${escape(visit?.time)}"></label>
      </div>
      <label>Заметка<textarea name="note" rows="2" maxlength="800">${escape(visit?.note)}</textarea></label>
      <p class="editor-error" role="alert" hidden></p>
      <div class="actions">
        <button class="action-link action-primary" type="submit">${visit ? 'Сохранить визит' : 'Добавить в план'}</button>
        ${visit ? '<button class="action-link editor-remove" type="button" data-editor="remove">Убрать из плана</button>' : ''}
      </div>
    </form>`;
    this.form = this.dialog.querySelector('form')!;
    this.renderChoice();
    this.dialog.showModal();
  }

  resume(coords?: Coords) {
    if (coords) this.form.querySelector<HTMLInputElement>('[name="coords"]')!.value = coords.map(value => value.toFixed(5)).join(', ');
    this.dialog.showModal();
  }

  private renderChoice() {
    const choice = this.form.querySelector<HTMLElement>('.editor-choice')!;
    const search = this.form.querySelector<HTMLElement>('.editor-search')!;
    const own = this.form.querySelector<HTMLElement>('.editor-own')!;
    choice.hidden = !this.chosen;
    search.hidden = own.hidden = Boolean(this.chosen);
    choice.innerHTML = this.chosen ? `<strong>${escape(this.chosen.name)}</strong>
      <button type="button" class="action-link" data-editor="own">Выбрать другое место</button>` : '';
    if (!this.chosen) this.renderMatches();
  }

  private renderMatches() {
    const search = this.form.querySelector<HTMLInputElement>('#visit-search')!;
    const results = this.form.querySelector<HTMLElement>('#visit-matches')!;
    const query = search.value.trim();
    const unchanged = this.visit?.place && 'name' in this.visit.place && this.visit.place.name === query;
    const matches = query ? this.options.places().filter(place => matchesPlace(place, query)).slice(0, 6) : [];
    results.innerHTML = matches.map(place => `<button type="button" class="result" data-choose="${escape(place.id)}">
      <span><strong>${escape(place.name)}</strong><small>${escape(place.ko)}</small></span></button>`).join('');
    if (query && !matches.length && !unchanged) results.textContent = 'Добавится как новое место.';
  }

  private save() {
    const formData = new FormData(this.form);
    const field = (name: string) => String(formData.get(name) ?? '').trim();
    const date = field('date');
    const time = field('time');
    const name = field('name');
    const coordText = field('coords');
    const coords = coordText ? parseCoords(coordText) : null;
    const error = this.form.querySelector<HTMLElement>('.editor-error')!;
    const message = !dates.includes(date) ? 'Выбери день поездки.'
      : time && !isVisitTime(time) ? 'Укажи время в формате часы и минуты.'
        : !this.chosen && !name ? 'Выбери место или введи название.'
          : !this.chosen && coordText && !coords ? 'Введи две координаты, например 37.56654, 126.97802.' : '';
    error.hidden = !message;
    error.textContent = message;
    if (message) return;
    const id = this.visit?.id ?? 'visit-' + crypto.randomUUID().toLowerCase();
    this.dialog.close();
    this.options.save({
      id, date, time, note: field('note').slice(0, 800),
      place: this.chosen ? { placeId: this.chosen.id } : { name, address: field('address'), coords }
    });
  }
}

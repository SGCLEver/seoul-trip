export type PackageIndex = { version: string; bytes: number; assets: { path: string; bytes: number; shared?: boolean }[] };
export const siteRoot = new URL(import.meta.env.BASE_URL, document.baseURI);
const prefix = 'seoul-offline:' + siteRoot.pathname + ':';
const sharedName = 'seoul-maps:' + siteRoot.pathname;
const assetUrl = (path: string) => new URL(path, siteRoot);
let registration: Promise<ServiceWorkerRegistration> | undefined;
let latestCheck: Promise<PackageIndex | null> | undefined;

export async function checkForUpdates(): Promise<PackageIndex | null> {
  if (latestCheck) return latestCheck;
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), 4500);
  latestCheck = fetch(assetUrl('offline-index.json?remote=1'), { cache: 'no-store', signal: controller.signal })
    .then(response => response.ok ? response.json() as Promise<PackageIndex> : null)
    .catch(() => null)
    .finally(() => { clearTimeout(timer); latestCheck = undefined; });
  return latestCheck;
}

function worker(): Promise<ServiceWorkerRegistration> {
  if (!('serviceWorker' in navigator) || !window.isSecureContext) {
    return Promise.reject(new Error('Для загрузки нужен HTTPS или локальный адрес для проверки.'));
  }
  registration ??= navigator.serviceWorker.register(assetUrl('sw.js'), { scope: siteRoot.pathname })
    .then(() => navigator.serviceWorker.ready)
    .catch(error => { registration = undefined; throw error; });
  return registration;
}

export async function savedPackage(): Promise<PackageIndex | null> {
  if (!('caches' in window)) return null;
  try {
    const names = (await caches.keys()).filter(name => name.startsWith(prefix)).reverse();
    let sharedKeys: Set<string> | undefined;
    for (const name of names) {
      const store = await caches.open(name);
      if (!await store.match(assetUrl('offline-ready'))) continue;
      const data = await store.match(assetUrl('offline-index.json'));
      if (!data) continue;
      const index = await data.json() as PackageIndex;
      const keys = new Set((await store.keys()).map(request => request.url));
      if (!sharedKeys && index.assets.some(asset => asset.shared)) {
        sharedKeys = await caches.has(sharedName)
          ? new Set((await (await caches.open(sharedName)).keys()).map(request => request.url))
          : new Set();
      }
      if (index.assets.every(asset => (asset.shared ? sharedKeys : keys)?.has(assetUrl(asset.path).href))) return index;
    }
  } catch {}
  return null;
}

export function pendingBytes(remote: PackageIndex, saved: PackageIndex | null) {
  const savedPaths = new Set(saved?.assets.map(asset => asset.path) ?? []);
  return remote.assets.reduce((size, asset) =>
    size + (asset.path.startsWith('assets/') && savedPaths.has(asset.path) ? 0 : asset.bytes), 0);
}

export async function downloadOffline(onProgress: (percent: number) => void): Promise<string> {
  const active = (await worker()).active;
  if (!active) throw new Error('Открой приложение ещё раз, чтобы включить офлайн-режим.');
  return new Promise<string>((resolve, reject) => {
    const channel = new MessageChannel();
    const timer = window.setTimeout(() => {
      channel.port1.close();
      reject(new Error('Загрузка заняла слишком много времени. Попробуй ещё раз.'));
    }, 9 * 60 * 1000);
    channel.port1.onmessage = ({ data }) => {
      if (data.type === 'progress') {
        onProgress(data.percent);
        return;
      }
      window.clearTimeout(timer);
      channel.port1.close();
      if (data.type === 'ready') resolve(data.version);
      else reject(new Error(data.message || 'Не удалось сохранить офлайн-пакет.'));
    };
    active.postMessage({ type: 'download' }, [channel.port2]);
  });
}

export function initOffline(): void {
  if (import.meta.env.PROD) void worker().catch(() => {});
}

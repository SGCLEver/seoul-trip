import './style.css';
import type { TripMap, MapPlace } from './map';
import { checkForUpdates, downloadOffline, initOffline, pendingBytes, savedPackage, type PackageIndex } from './offline';
import {
  byId, checklist, days, dates, modes, outings, packingSuggestions, places, priorities, PROGRAM_DATE, seoulDate,
  type Coords, type Day, type Event, type Outing, type Place, type Priority
} from './trip';
import { hotelCoords, packingTextLimit, parseBackup, readState, saveState, settingsFields, type PersonalVisit, type Settings } from './storage';
import { escape, matchesPlace, short } from './text';
import { VisitEditor } from './visit-editor';

type View = 'map' | 'plan' | 'pack' | 'settings';
let local = readState();
let view: View = 'map';
let day = days.find(item => item.date === seoulDate()) ?? days.find(item => item.date === local.lastDay) ?? days[0];
let filteredDay = false;
let category: 'all' | 'personal' | Priority = 'all';
let area: 'seoul' | 'trip' = 'seoul';
let selected: string | undefined;
let query = '';
let showList = false;
let showFilters = false;
let installedPackage: PackageIndex | null = null;
let availablePackage: PackageIndex | null = null;
let downloading = false;
let progress = 0;
let offlineError = '';
let toastTimer = 0;
let lastUpdateCheck = 0;
let tripMap: TripMap | undefined;
let mapLoading: Promise<TripMap | undefined> | undefined;
let editorView: View = 'plan';
let picking = false;
let editingPacking: string | undefined;
let packingDraft = '';

const app = document.querySelector<HTMLElement>('#app')!;
app.innerHTML = `
  <div class="shell">
    <header class="page-header">
      <div class="brand">
        <img src="./icon-192.png" alt="" width="42" height="42">
        <div><h1>Сеул <span lang="ko">서울</span></h1><p>22–27 февраля 2027</p></div>
      </div>
      <button type="button" class="offline-pill" id="offline-pill" data-view="settings"></button>
    </header>
    <main class="stage">
      <section class="map-page" aria-label="Карта" id="map-page">
        <div id="map"></div>
        <div class="pick-bar" id="pick-bar" hidden><p>Коснись карты, чтобы поставить точку.</p>
          <button class="action-link" type="button" data-action="cancel-pin">Отмена</button></div>
        <div class="map-tools">
          <div class="map-toolbar">
            <label class="search"><span aria-hidden="true" class="search-icon"></span><input id="query" type="search" autocomplete="off" spellcheck="false" placeholder="Найти место" aria-label="Найти место"></label>
            <button class="filter-button" type="button" data-action="filters" aria-pressed="false" aria-controls="filters"><span class="filter-icon" aria-hidden="true">☷</span><span>Фильтры</span></button>
          </div>
          <div class="map-chips">
            <button type="button" class="chip" data-action="area" aria-pressed="false">Вся поездка</button>
            <button type="button" class="chip" data-action="list" aria-pressed="false" aria-controls="map-list">Список мест</button>
            <button type="button" class="chip" data-action="home" id="map-home" hidden>В отель</button>
          </div>
          <div class="map-panel" id="filters" hidden></div>
          <div class="map-panel" id="map-list" hidden></div>
        </div>
        <div id="map-warning" class="map-warning" role="status" hidden>Карта улиц не загрузилась. Попробуй обновить страницу или скачать её в настройках.</div>
        <div class="map-controls">
          <div class="zoom-buttons"><button type="button" data-action="zoom-in" aria-label="Приблизить">+</button><button type="button" data-action="zoom-out" aria-label="Отдалить">−</button></div>
          <button class="locate" type="button" data-action="locate"><span aria-hidden="true">◎</span> Где я</button>
        </div>
      </section>
      <section class="scroll-page" id="content" hidden></section>
      <section class="place-sheet" id="sheet" aria-label="Карточка места" hidden></section>
    </main>
    <nav class="tabbar" aria-label="Разделы поездки">
      ${([['map','Карта','map'], ['plan','План','plan'], ['pack','Сборы','pack'], ['settings','Настройки','settings']] as const)
        .map(([id, title, icon]) => `<button type="button" data-view="${id}"><span aria-hidden="true" class="nav-icon icon-${icon}"></span>${title}</button>`).join('')}
    </nav>
  </div>
  <dialog id="visit-editor" class="visit-editor" aria-labelledby="visit-editor-title"></dialog>
  <div class="toast" id="toast" role="status" aria-live="polite" hidden></div>`;

const $ = <T extends HTMLElement = HTMLElement>(selector: string) => app.querySelector<T>(selector)!;
const mapPage = $('#map-page');
const content = $('#content');
const sheet = $('#sheet');
const list = $('#map-list');
const filters = $('#filters');
const search = $<HTMLInputElement>('#query');
const visitEditor = new VisitEditor($<HTMLDialogElement>('#visit-editor'), {
  places: () => places.map(place => placeFor(place.id)!),
  save: saveVisit,
  remove: removeVisit,
  pick: startPicking
});

function getMap() {
  mapLoading ??= import('./map').then(({ TripMap: Map }) => {
    tripMap = new Map($('#map'), openGroup, () => { $('#map-warning').hidden = false; });
    return tripMap;
  }).catch(() => {
    $('#map-warning').hidden = false;
    mapLoading = undefined;
    return undefined;
  });
  return mapLoading;
}
const goodUrl = (value: string) => /^https:\/\//i.test(value) ? value : '';
const navSearch = (place: string) => 'https://map.naver.com/p/search/' + encodeURIComponent(place);
const googleSearch = (place: string) => 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(place);
const personalPlaces = new Set(days.flatMap(item => item.outings.flatMap(outing => outing.stops)));

function placeFor(id: string): Place | undefined {
  const place = byId.get(id);
  if (!place) {
    const visit = local.visits.find(entry => entry.id === id);
    if (!visit || 'placeId' in visit.place) return;
    const { name, address, coords } = visit.place;
    const korean = /[\uac00-\ud7a3]/.test(address);
    const target = [name, address || '대한민국'].join(' ');
    return {
      id, name, ko: '', addressKo: korean ? address : '', addressLatin: korean ? '' : address, coords,
      kind: 'Своё место', info: visit.note || 'Добавлено в личный план.',
      maps: { naver: navSearch(target), google: googleSearch(coords?.join(',') ?? target) },
      sources: [], sourceDate: ''
    };
  }
  const settings = local.settings;
  if (id !== 'hotel' || !hasHotel()) return place;
  const target = settings.hotelKo || settings.hotel || hotelCoords(settings)?.join(',') || '';
  return {
    ...place, name: settings.hotel || 'Отель', ko: '', addressKo: settings.hotelKo,
    coords: hotelCoords(settings), approach: settings.station, info: 'Данные из твоих настроек.',
    maps: { naver: navSearch(target), google: googleSearch(target) }, sourceDate: ''
  };
}

function hasHotel() { return Boolean(local.settings.hotelKo || local.settings.hotel || hotelCoords(local.settings)); }
function unavailable(place: Place) { return place.closed || (place.id === 'gyeongbokgung' && day.date === dates[1] ? '23.02 закрыт' : ''); }
function assignedOutings(on: Day) {
  return [...outings.values()].filter(outing => (local.moved[outing.id] || days.find(d => d.outings.includes(outing))?.date) === on.date);
}
const visitsOn = (on: Day) => local.visits.filter(visit => visit.date === on.date)
  .sort((first, second) => (first.time || '99:99').localeCompare(second.time || '99:99'));
const visitPlaceId = (visit: PersonalVisit) => 'placeId' in visit.place ? visit.place.placeId : visit.id;

function saveVisit(visit: PersonalVisit) {
  const index = local.visits.findIndex(entry => entry.id === visit.id);
  if (index === -1) local.visits.push(visit);
  else local.visits[index] = visit;
  selectDay(visit.date);
  persist();
  filteredDay = false;
  switchView('plan');
  $('#personal-plan').scrollIntoView({ block: 'start' });
  app.querySelector<HTMLElement>('[data-edit-visit="' + visit.id + '"]')?.focus({ preventScroll: true });
  flash(index === -1 ? 'Место добавлено на ' + short(visit.date) : 'Визит сохранён на ' + short(visit.date));
}

function removeVisit(visit: PersonalVisit) {
  local.visits = local.visits.filter(entry => entry.id !== visit.id);
  delete local.visited[visit.id];
  persist();
  switchView('plan');
  $('#personal-plan').scrollIntoView({ block: 'start' });
  flash('Визит убран из плана.');
}

function startPicking() {
  editorView = view;
  view = 'map';
  selected = undefined;
  sheet.hidden = true;
  picking = true;
  $('#pick-bar').hidden = false;
  $('.map-tools').hidden = true;
  drawView();
  void getMap().then(map => { if (picking) map?.pick(finishPicking); });
}

function clearPicker() {
  picking = false;
  tripMap?.pick();
  $('#pick-bar').hidden = true;
  $('.map-tools').hidden = false;
}

function finishPicking(coords?: Coords) {
  clearPicker();
  view = editorView;
  drawView();
  setHash();
  visitEditor.resume(coords);
}

function eventPlace(event: Event): string | undefined {
  const terminal = event.id === 'd2-arrival' ? local.settings.arrivalTerminal
    : ['d7-transfer', 'd7-departure'].includes(event.id) ? local.settings.departureTerminal : '';
  return terminal === 'T1' || terminal === 'T2' ? 'icn-' + terminal.toLowerCase() : event.placeId;
}

function dayIds(on: Day) {
  const ids = new Set(on.events.map(eventPlace).filter(Boolean));
  if (on.tour === 2 || on.tour === 7) { ids.add('icn-t1'); ids.add('icn-t2'); }
  if (on.tour === 3) ids.add('gyeongbokgung');
  if (on.tour === 4) ids.add('sky-bridge');
  for (const outing of assignedOutings(on)) for (const id of outing.stops) ids.add(id);
  for (const visit of visitsOn(on)) ids.add(visitPlaceId(visit));
  return ids;
}
function priorityFor(id: string): Priority {
  if (id.startsWith('visit-') || id === 'sky-bridge' || id === 'love-locks') return 'want';
  if (['icn-t1','icn-t2','gyeongbokgung'].includes(id) || days.some(on => on.events.some(event => event.placeId === id))) return 'group';
  const options = [...outings.values()].filter(outing => outing.stops.includes(id)).map(outing => outing.priority);
  if (options.includes('want')) return 'want';
  if (options.includes('option')) return 'option';
  return 'reserve';
}
function visible() {
  const ids = dayIds(day);
  const personallyAdded = new Set((filteredDay ? visitsOn(day) : local.visits).map(visitPlaceId));
  const known = [...places.map(place => place.id), ...local.visits.filter(visit => 'name' in visit.place).map(visit => visit.id)];
  return known.flatMap(id => {
    const place = placeFor(id);
    if (!place) return [];
    if (filteredDay && !ids.has(place.id)) return [];
    const priority = priorityFor(place.id);
    if (category === 'personal' && !personalPlaces.has(place.id) && !personallyAdded.has(place.id) && priority === 'group') return [];
    if (category !== 'all' && category !== 'personal' && category !== priority) return [];
    if (!matchesPlace(place, query)) return [];
    return [{ ...place, priority, unavailable: Boolean(unavailable(place)), visited: Boolean(local.visited[place.id]) }];
  });
}
const badge = (priority: Priority) => `<span class="badge badge-${priority}">${priorities[priority]}</span>`;
const placeButton = (id: string, label?: string, jump = false) => `<button type="button" data-place="${escape(id)}" ${jump ? 'data-jump="true"' : ''} class="place-link">${escape(label ?? placeFor(id)?.name ?? id)} <span aria-hidden="true">↗</span></button>`;

function flash(message: string) {
  const toast = $('#toast');
  clearTimeout(toastTimer);
  toast.textContent = message;
  toast.hidden = false;
  toastTimer = window.setTimeout(() => { toast.hidden = true; }, 4000);
}
function persist() {
  try { saveState(local); }
  catch { flash('Браузер не сохранил изменение. Его можно выгрузить в JSON.'); }
}

function updateHeader() {
  const pill = $('#offline-pill');
  pill.innerHTML = `<span class="status-dot${installedPackage ? ' status-ready' : ''}"></span>${installedPackage ? 'Офлайн готов' : 'Офлайн'}`;
  document.documentElement.classList.toggle('network-off', !navigator.onLine);
  for (const tab of app.querySelectorAll<HTMLElement>('.tabbar [data-view]')) {
    tab.dataset.view === view ? tab.setAttribute('aria-current', 'page') : tab.removeAttribute('aria-current');
  }
}
function renderMap() {
  const matched = visible();
  const forced = selected && placeFor(selected);
  const pinned: MapPlace[] = forced && !matched.some(p => p.id === forced.id)
    ? [...matched, { ...forced, priority: priorityFor(forced.id), unavailable: Boolean(unavailable(forced)), visited: Boolean(local.visited[forced.id]) }]
    : matched;
  tripMap?.render(pinned, selected);
  const filterButton = $('[data-action="filters"]');
  filterButton.setAttribute('aria-pressed', String(showFilters || filteredDay || category !== 'all'));
  $('[data-action="area"]').setAttribute('aria-pressed', String(area === 'trip'));
  $('[data-action="list"]').setAttribute('aria-pressed', String(showList));
  $('#map-home').hidden = !hasHotel();
  filters.hidden = !showFilters;
  list.hidden = !(showList || query);
  if (showFilters) {
    filters.innerHTML = `
      <label>Дата <select id="map-date" aria-label="День на карте"><option value="">Все дни</option>
        ${days.map(item => `<option value="${item.date}" ${filteredDay && day === item ? 'selected' : ''}>${item.label}, ${short(item.date)} · день ${item.tour}</option>`).join('')}</select></label>
      <label>Места <select id="map-category" aria-label="Тип места">
        ${Object.entries({ all: 'Все места', personal: 'Личные планы', ...priorities }).map(([id, name]) =>
          `<option value="${id}" ${id === category ? 'selected' : ''}>${name}</option>`).join('')}</select></label>
      <div class="legend">${(Object.keys(priorities) as Priority[]).map(badge).join('')}</div>`;
  }
  if (!list.hidden) {
    const shown = matched.filter(place => place.coords || query || place.id.startsWith('visit-'));
    list.innerHTML = `<div class="results-head">${query ? 'Результаты' : 'Места на карте'} <span>${shown.length}</span></div>
      ${shown.length ? shown.map(place => `<button type="button" data-place="${place.id}" data-jump="true" class="result">
        <span><strong>${escape(place.name)}</strong>${place.ko ? `<small lang="ko">${escape(place.ko)}</small>` : ''}</span>
        ${place.unavailable ? '<span class="closed-mark">Закрыто</span>' : badge(place.priority)}</button>`).join('') : '<p class="empty">Ничего не нашлось.</p>'}`;
  }
}

function selectDay(date: string) {
  const found = days.find(item => item.date === date);
  if (!found) return;
  day = found;
  if (local.lastDay !== found.date) {
    local.lastDay = found.date;
    persist();
  }
}
function setHash() {
  const hash = selected ? 'place/' + selected + '?day=' + day.tour
    : view === 'plan' ? 'day/' + day.tour : view === 'map' ? '' : view;
  history.replaceState(null, '', location.pathname + location.search + (hash ? '#' + hash : ''));
}
function drawView() {
  mapPage.hidden = view !== 'map';
  content.hidden = view === 'map';
  if (view === 'map') {
    renderMap();
    void getMap().then(map => {
      if (!map || view !== 'map') return;
      map.resize();
      renderMap();
    });
  } else if (view === 'plan') renderPlan();
  else if (view === 'pack') renderChecklist();
  else renderSettings();
  updateHeader();
}
function switchView(next: View) {
  if (picking) clearPicker();
  if (next !== 'pack' && editingPacking) {
    editingPacking = undefined;
    packingDraft = '';
  }
  selected = undefined;
  sheet.hidden = true;
  view = next;
  content.scrollTop = 0;
  drawView();
  setHash();
}

function openGroup(ids: string[]) {
  if (picking) {
    const coords = placeFor(ids[0])?.coords;
    if (coords) finishPicking(coords);
    return;
  }
  showList = showFilters = false;
  query = '';
  search.value = '';
  if (ids.length === 1) { openPlace(ids[0]); return; }
  selected = undefined;
  renderMap();
  const sameLocation = new Set(ids.map(id => placeFor(id)?.coords?.join(','))).size === 1;
  sheet.hidden = false;
  sheet.innerHTML = `<div class="grabber"></div><div class="sheet-head"><h2>${sameLocation ? escape(placeFor(ids[0])?.name) : 'Места рядом'}</h2>${closeButton}</div>
    <div class="sheet-body cluster-list">${ids.map(id => placeButton(id, undefined, !sameLocation)).join('')}</div>`;
  sheet.querySelector<HTMLElement>('.close-sheet')?.focus({ preventScroll: true });
}
const closeButton = '<button class="close-sheet" type="button" data-action="close" aria-label="Закрыть карточку">×</button>';

function openPlace(id: string, jump = false) {
  const place = placeFor(id);
  if (!place) return;
  if (jump && place.coords) {
    view = 'map';
    showList = showFilters = false;
    query = '';
    search.value = '';
    search.blur();
  }
  selected = id;
  drawView();
  showPlace(place);
  if (jump && place.coords) {
    void getMap().then(map => {
      if (view !== 'map' || id !== selected) return;
      const covered = window.innerWidth < 650 ? sheet.offsetHeight : 0;
      map?.focus(place, covered);
    });
  }
  setHash();
}

function netLink(label: string, url: string, primary = false) {
  return goodUrl(url) ? `<a class="action-link${primary ? ' action-primary' : ''}" data-online href="${escape(url)}" target="_blank" rel="noopener noreferrer">${label} <span aria-hidden="true">↗</span></a>` : '';
}

function nativeRoute(place: Place, from?: Place) {
  const coordinates = from?.coords || tripMap?.userLocation;
  if (!coordinates || !place.coords || coordinates[0] < 31.43 || coordinates[0] > 44.35 ||
    coordinates[1] < 122.37 || coordinates[1] > 132) return '';
  const args = { slat: coordinates[0], slng: coordinates[1], sname: from?.ko || from?.name || '내 위치',
    dlat: place.coords[0], dlng: place.coords[1], dname: place.ko || place.name, appname: location.host };
  const q = Object.entries(args).map(([key, value]) => key + '=' + encodeURIComponent(value)).join('&');
  return `<a class="action-link" data-online href="nmap://route/public?${escape(q)}">Маршрут в приложении NAVER</a>`;
}

function showPlace(place: Place, focus = true) {
  const status = unavailable(place);
  const hours = place.hours?.find(item => item.dates?.includes(day.date)) ?? place.hours?.find(item => !item.dates);
  const related = places.filter(other => other.parent === place.id || place.parent === other.id);
  const visited = Boolean(local.visited[place.id]);
  const address = place.addressKo || place.addressLatin;
  const ownVisit = local.visits.find(visit => visit.id === place.id);
  sheet.hidden = false;
  sheet.innerHTML = `
    <div class="grabber"></div><div class="sheet-head"><div>
      <div class="sheet-meta">${badge(priorityFor(place.id))}${status ? `<span class="closed-mark">${status}</span>` : ''}</div>
      <h2>${escape(place.name)}</h2>
      ${place.ko ? `<p lang="ko" class="native-name">${escape(place.ko)}</p>` : ''}
    </div>${closeButton}</div>
    <div class="sheet-body">
      ${place.kind ? `<p class="muted marker-label">${escape(place.kind)}</p>` : ''}
      ${address ? `<div class="address"><strong lang="ko">${escape(place.addressKo)}</strong><small>${escape(place.addressLatin)}</small></div>` : ''}
      <div class="actions">${netLink('NAVER Map', place.maps.naver, true)}${netLink('Google Maps', place.maps.google)}${address
        ? '<button class="action-link" type="button" data-action="copy">Скопировать адрес</button>' : ''}
        <button type="button" class="action-link" ${ownVisit ? `data-edit-visit="${ownVisit.id}"` : `data-add-place="${place.id}"`}>
          ${ownVisit ? 'Изменить визит' : 'Добавить в личный план'}</button></div>
      ${place.coords && view !== 'map' ? `<div class="actions">${placeButton(place.id, 'Показать на карте', true)}</div>` : ''}
      ${hours ? `<div class="fact"><h3>Часы места · ${short(day.date)}</h3><p>${escape(hours.text)}</p>
        ${hours.last ? `<p>Последний вход / рейс: ${escape(hours.last)}</p>` : ''}${hours.shop ? `<p>${escape(hours.shop)}</p>` : ''}
        ${hours.ticket ? `<p>${escape(hours.ticket)}</p>` : ''}</div>` : ''}
      ${place.approach ? `<div class="fact"><h3>Как подойти</h3><p>${escape(place.approach)}</p></div>` : ''}
      <div class="fact"><h3>На месте</h3><p>${escape(place.info)}</p>${place.coords ? `<p class="coords">${place.coords.map(value => value.toFixed(5)).join(', ')}</p>` : ''}</div>
      ${related.length ? `<div class="fact"><h3>В этом комплексе</h3>${related.map(other => placeButton(other.id)).join('')}</div>` : ''}
      <div class="actions">${nativeRoute(place, local.startAtHotel ? placeFor('hotel') : undefined)}
        ${place.booking ? netLink(place.id.startsWith('apple') ? 'Аксессуары Apple' : 'Билеты и условия', place.booking) : ''}
        <button type="button" class="action-link" data-visited="${place.id}" aria-pressed="${visited}">${visited ? '✓ Посещено' : 'Отметить посещение'}</button>
      </div>
      ${place.sourceDate && place.coords ? `<details class="source-details"><summary>Источники и дата проверки</summary>
        <p>Данные карточки от ${PROGRAM_DATE}. ${place.verified ? 'Официальный источник проверен.' : 'Сведения из программы поездки.'} Обычные часы стоит перепроверить ближе к поездке.</p>
        <div class="actions">${place.verified ? netLink('Официальный источник', place.verified) : ''}${place.sources.map(source => netLink(escape(source.name), source.url)).join('')}</div></details>` : ''}
    </div>`;
  if (focus) sheet.querySelector<HTMLElement>('.close-sheet')?.focus({ preventScroll: true });
}

function terminalLinks(terminal: string) {
  return `<div class="terminal-links">${['T1', 'T2'].map(term =>
    `<span class="${terminal === term ? 'confirmed-terminal' : ''}">${placeButton('icn-' + term.toLowerCase(), term, true)}</span>`).join('')}</div>`;
}

function renderToday() {
  const current = days.find(item => item.date === seoulDate());
  if (current && current !== day) {
    return `<section class="today-card"><div><h3>Сегодня в Сеуле</h3><p>${short(current.date)} · ${escape(current.theme)}</p></div>
      <button type="button" data-day="${current.date}" class="action-link">К сегодняшнему дню</button></section>`;
  }
  const next = day.events.find(event => !local.visited[event.id]);
  const placeId = next && eventPlace(next);
  const meeting = next?.id === 'd2-transfer' ? local.settings.arrivalMeeting
    : next?.id === 'd7-transfer' ? local.settings.departureMeeting : '';
  return `<section class="today-card">
    <div><h3>${current ? 'Сегодня' : 'По порядку'} · ${short(day.date)}</h3>
      <p>${next ? 'Дальше: ' + escape(next.title) : 'Все групповые пункты отмечены.'}</p>
      ${next?.start ? `<p class="today-note">Начало в ${escape(next.start)} по Сеулу</p>` : ''}
      ${meeting ? `<p class="today-note">Встреча · ${escape(meeting)}</p>` : ''}
    </div>
    <div class="actions">
      ${placeId ? `<button class="action-link" type="button" data-place="${placeId}" data-jump="true">${placeFor(placeId)?.coords ? 'Показать на карте' : 'Открыть карточку'}</button>` : ''}
      ${next ? `<button class="action-link" type="button" data-event-done="${next.id}" aria-label="Отметить следующий пункт">✓ Готово</button>` : ''}
      ${hasHotel() ? '<button type="button" class="action-link" data-action="home">В отель</button>' : ''}
    </div>
  </section>`;
}

function renderVisit(visit: PersonalVisit) {
  const id = visitPlaceId(visit);
  const place = placeFor(id);
  const done = Boolean(local.visited[visit.id]);
  return `<article class="section-card personal-visit">
    <div class="visit-plan-head">
      <span class="mode">${visit.time ? escape(visit.time) + ' KST' : 'Без времени'}</span>
      ${place ? placeButton(id, undefined, Boolean(place.coords)) : '<strong>Место из резервной копии</strong>'}
    </div>
    ${visit.note ? `<p class="muted">${escape(visit.note)}</p>` : ''}
    <div class="actions">
      <button class="action-link" data-visit-done="${visit.id}" type="button" aria-pressed="${done}">${done ? '✓ Посещено' : 'Отметить посещение'}</button>
      <button class="action-link" data-edit-visit="${visit.id}" type="button">Изменить визит</button>
    </div>
  </article>`;
}

function renderPlan() {
  const dayOutings = assignedOutings(day);
  const custom = visitsOn(day);
  content.innerHTML = `<div class="page-inner">
    <div class="page-title plan-heading"><div><h2>План поездки</h2><p class="muted">Время Сеула · KST</p></div>
      <button class="action-link action-primary" type="button" data-action="add-visit">Добавить место</button></div>
    <div class="day-rail" aria-label="Дни поездки">${days.map(item => `<button type="button" data-day="${item.date}" aria-pressed="${day === item}">
      <span>${item.label}</span><strong>${short(item.date)}</strong><small>День ${item.tour}</small>
    </button>`).join('')}</div>
    <h3 class="day-title">${escape(day.theme)}</h3>
    ${renderToday()}
    <section class="section-card" aria-label="Групповая программа"><h3><span class="section-dot"></span>Групповая программа</h3>
      <ol class="timeline">${day.events.map(renderEvent).join('')}</ol>
    </section>
    <section class="outings" id="personal-plan">
      <div class="page-title"><h3>Личный план</h3></div>
      ${hasHotel() && dayOutings.length ? `<label class="starting"><input id="start-at-hotel" type="checkbox" ${local.startAtHotel ? 'checked' : ''}> По возможности начать из отеля</label>` : ''}
      <div id="custom-visits">${custom.map(renderVisit).join('')}</div>
      ${dayOutings.map(renderOuting).join('')}
    </section>
  </div>`;
}
function renderEvent(event: Event) {
  const placeId = eventPlace(event);
  const flight = event.id === 'd2-arrival' ? local.settings.arrivalFlight : event.id === 'd7-departure' ? local.settings.departureFlight : '';
  const airport = event.id === 'd2-arrival' || event.id === 'd7-departure';
  const meeting = event.id === 'd2-transfer' ? local.settings.arrivalMeeting : event.id === 'd7-transfer' ? local.settings.departureMeeting : '';
  const done = Boolean(local.visited[event.id]);
  return `<li class="event">
    <div class="event-time">${event.start ? escape(event.start + (event.end ? '–' + event.end : '')) : 'Время уточняется'}${event.mode ? `<span class="mode">${modes[event.mode]}</span>` : ''}</div>
    <div class="event-title">
      ${placeId ? placeButton(placeId, event.title, true) : `<strong>${escape(event.title)}</strong>`}
      <button class="event-done" type="button" data-event-done="${event.id}" aria-pressed="${done}"
        aria-label="${done ? 'Снять отметку' : 'Отметить'}: ${escape(event.title)}">${done ? '✓' : '<span></span>'}</button>
    </div>
    ${flight ? `<p class="muted">${escape(flight)}</p>` : ''}
    ${meeting || event.note ? `<p class="event-note">${escape(meeting || event.note)}</p>` : ''}
    ${airport ? terminalLinks(event.id === 'd2-arrival' ? local.settings.arrivalTerminal : local.settings.departureTerminal) : ''}
    ${event.id === 'd7-transfer' ? `<details><summary>AREX · самостоятельный вариант</summary><p>Посадка на B1 транспортного центра. Проверь станцию, расписание и терминал.</p>${netLink('Расписание AREX', 'https://www.arex.or.kr/main.do')}</details>` : ''}
  </li>`;
}
function renderOuting(outing: Outing) {
  const anchor = day.events.find(item => item.id === outing.dependsOn);
  const last = [...day.events].reverse().find(item => item.placeId && item.placeId !== 'hotel');
  const start = local.startAtHotel && hasHotel() ? placeFor('hotel') :
    placeFor(anchor?.placeId ?? last?.placeId ?? '');
  const first = placeFor(outing.stops[0]);
  return `<article class="section-card outing">
    <div class="outing-title">${badge(outing.priority)}<h4>${escape(outing.title)}</h4></div>
    <p>${escape(outing.condition)}</p>
    ${start ? `<p class="muted">Старт · ${escape(start.name)}${!anchor && !local.startAtHotel ? ' (последняя известная точка дня)' : ''}</p>` : ''}
    <div class="stops">${outing.stops.map(id => placeButton(id, undefined, true)).join('')}</div>
    <details><summary>Маршрут и время</summary>
      <ol class="route-steps">${outing.steps.map(step => `<li><span class="mode">${modes[step.mode]}</span> ${escape(step.text)}</li>`).join('')}</ol>
      ${outing.recommendation ? `<p>${escape(outing.recommendation)}</p>` : ''}
      <p class="muted">Проверь фактический маршрут и последние рейсы в NAVER Map в день прогулки.</p>
      <div class="actions">${first ? netLink('NAVER Map', first.maps.naver) + (start ? nativeRoute(first, start) : '') : ''}</div>
    </details>
    <label class="move-label">Перенести <select data-move="${outing.id}">
      ${days.filter(item => item.outings.length || item.date === day.date).map(item =>
        `<option value="${item.date}" ${item.date === day.date ? 'selected' : ''}>${item.label}, ${short(item.date)}</option>`).join('')}
    </select></label>
  </article>`;
}
function packingName(text: string) {
  return text.trim().replace(/\s+/g, ' ').toLocaleLowerCase('ru');
}
function packingExists(text: string, except?: string) {
  const key = packingName(text);
  return checklist.some(([, title]) => packingName(title) === key) ||
    local.packing.some(item => item.id !== except && packingName(item.text) === key);
}

function savePackingItem(raw: string, id?: string, resetEditor = true) {
  const text = raw.trim();
  if (!text || text.length > packingTextLimit) {
    flash('Введи название пункта до ' + packingTextLimit + ' символов.');
    return false;
  }
  if (packingExists(text, id)) {
    flash('Такой пункт уже есть в списке.');
    return false;
  }
  const item = local.packing.find(entry => entry.id === id);
  if (item) item.text = text;
  else local.packing.push({ id: 'pack-' + crypto.randomUUID(), text });
  if (resetEditor) {
    editingPacking = undefined;
    packingDraft = '';
  }
  persist();
  renderChecklist();
  return true;
}

function renderChecklist() {
  const count = checklist.filter(([id]) => local.checked[id]).length +
    local.packing.filter(item => local.checked[item.id]).length;
  const editing = local.packing.find(item => item.id === editingPacking);
  const suggestionsOpen = app.querySelector<HTMLDetailsElement>('.packing-suggestions')?.open;
  const box = (id: string, text: string) =>
    `<label><input type="checkbox" data-check="${id}" ${local.checked[id] ? 'checked' : ''}><span>${escape(text)}</span></label>`;
  content.innerHTML = `<div class="page-inner">
    <div class="page-title"><h2>Сборы</h2><span class="muted">${count} из ${checklist.length + local.packing.length}</span></div>
    <p class="intro">Ориентир для одежды из заметок: −2…+6 °C.</p>
    <form class="section-card packing-form" id="packing-form">
      <label for="packing-text">${editing ? 'Изменить пункт' : 'Свой пункт'}</label>
      <div class="packing-form-row">
        <input id="packing-text" name="text" type="text" maxlength="${packingTextLimit}" value="${escape(packingDraft)}"
          placeholder="Например, распечатать билеты" required>
        <button class="action-link action-primary" type="submit">${editing ? 'Сохранить' : 'Добавить'}</button>
        ${editing ? '<button class="action-link" type="button" data-action="cancel-packing">Отмена</button>' : ''}
      </div>
    </form>
    <div class="section-card checklist">
      ${checklist.map(([id, text]) => box(id, text)).join('')}
      ${local.packing.map(item => `<div class="packing-row">${box(item.id, item.text)}
        <button type="button" class="packing-icon" data-edit-packing="${item.id}" aria-label="Изменить: ${escape(item.text)}">✎</button>
        <button type="button" class="packing-icon" data-remove-packing="${item.id}" aria-label="Убрать: ${escape(item.text)}">×</button>
      </div>`).join('')}
    </div>
    <details class="section-card packing-suggestions"${suggestionsOpen ? ' open' : ''}>
      <summary>Что проверить до вылета</summary>
      <div class="packing-recommendations">${packingSuggestions.map((text, index) => packingExists(text)
        ? `<div><span>${text}</span><span class="muted">В списке</span></div>`
        : `<div><span>${text}</span><button class="action-link" type="button" data-packing-suggestion="${index}"
            aria-label="Добавить: ${text}">Добавить</button></div>`).join('')}</div>
    </details>
  </div>`;
}
function renderOffline() {
  const box = $('#offline-settings');
  if (!box) return;
  const formatSize = (bytes: number) => new Intl.NumberFormat('ru', { maximumFractionDigits: 1 })
    .format(bytes >= 1e6 ? bytes / 1e6 : Math.ceil(bytes / 1000)) + (bytes >= 1e6 ? ' МБ' : ' КБ');
  const size = availablePackage?.bytes ?? installedPackage?.bytes;
  const update = availablePackage && installedPackage && availablePackage.version !== installedPackage.version
    ? formatSize(pendingBytes(availablePackage, installedPackage)) : '';
  box.innerHTML = `<h3>Карта без интернета</h3>
    <p id="network-status">${installedPackage ? 'Карта, адреса и программа доступны офлайн.' : 'Скачай карту и программу перед вылетом.'}${size ? ' Размер пакета: ' + formatSize(size) + '.' : ''}</p>
    ${update ? `<p class="update-notice">Есть обновление. Загрузить около ${update}.</p>` : ''}
    ${downloading ? `<progress value="${progress}" max="100" aria-label="Загрузка карты"></progress><span aria-live="polite">${progress}%</span>` : ''}
    <button class="action-link action-primary" type="button" data-action="download" ${downloading ? 'disabled' : ''}>
      ${update ? 'Обновить пакет' : installedPackage ? 'Скачать повторно' : 'Скачать для офлайна'}</button>
    ${offlineError ? `<p class="closed-mark" role="alert">${escape(offlineError)}</p>` : ''}
    <details><summary>Добавить на экран «Домой»</summary>
      <p>В Safari открой меню «Поделиться» → «На экран „Домой“». Включи «Открывать как веб-приложение», если Safari покажет этот пункт.</p>
      <p>Запусти «Сеул» с экрана «Домой», скачай карту там и открой приложение ещё раз в авиарежиме.</p>
      <p>В Android Chrome эта команда находится в меню браузера: «Добавить на главный экран».</p>
    </details>`;
}

function inputField(settings: Settings, key: keyof Settings, label: string) {
  if (key === 'notes') return `<label>${label}<textarea name="${key}" aria-label="${label}" rows="4">${escape(settings[key])}</textarea></label>`;
  if (key.endsWith('Terminal')) return `<label>${label}<select name="${key}" aria-label="${label}"><option value="">Пока неизвестно</option>${['T1', 'T2'].map(term =>
    `<option${settings[key] === term ? ' selected' : ''}>${term}</option>`).join('')}</select></label>`;
  return `<label>${label}<input name="${key}" aria-label="${label}" value="${escape(settings[key])}" ${key === 'lat' || key === 'lng' ? 'inputmode="decimal"' : ''} autocomplete="off"></label>`;
}
function renderSettings() {
  content.innerHTML = `<div class="page-inner">
    <div class="page-title"><h2>Настройки</h2></div>
    <section class="section-card" id="offline-settings"></section>
    <form id="settings-form" class="section-card settings-form">
      <h3>Отель, рейсы и встречи</h3>
      <p class="muted">Эти данные хранятся на этом устройстве. Координаты отеля нужны, чтобы поставить его на карту.</p>
      <div class="form-grid">${settingsFields.map(([key,label]) => inputField(local.settings, key, label)).join('')}</div>
      <div class="actions"><button class="action-link action-primary" type="submit">Сохранить настройки</button>
        ${hasHotel() ? '<button type="button" class="action-link" data-action="home">В отель</button>' : ''}</div>
    </form>
    <section class="section-card"><h3>Резервная копия</h3>
      <p>Экспорт сохраняет настройки, личный план, посещения и чек-лист. Импорт заменяет текущие записи.</p>
      <div class="actions">
        <button class="action-link" type="button" data-action="export">Экспорт JSON</button>
        <button class="action-link" type="button" data-action="import">Импорт JSON</button>
        <input id="import-file" type="file" accept=".json,application/json" hidden>
      </div>
    </section>
    <p class="program-stamp">Программа от ${PROGRAM_DATE} · Сеул, UTC+9</p>
  </div>`;
  renderOffline();
}

function readHash() {
  const value = location.hash.slice(1);
  const [, placeId, queryString] = /^place\/([a-z0-9-]+)(?:\?(.*))?$/.exec(value) ?? [];
  const picked = days.find(item => value === 'day/' + item.tour);
  if (picked) { day = picked; view = 'plan'; }
  else if (value === 'pack' || value === 'settings' || value === 'plan') view = value;
  else if (placeId && placeFor(placeId)) {
    const tour = new URLSearchParams(queryString).get('day');
    const dated = days.find(item => String(item.tour) === tour);
    if (dated) day = dated;
    openPlace(placeId, true);
    return;
  } else view = 'map';
  drawView();
}
async function verifyOffline() {
  installedPackage = await savedPackage();
  updateHeader();
  renderOffline();
}

async function refreshOffline() {
  await verifyOffline();
  const now = Date.now();
  if (!navigator.onLine || (lastUpdateCheck && now - lastUpdateCheck < 60000)) return;
  lastUpdateCheck = now;
  const next = await checkForUpdates();
  if (next) availablePackage = next;
  renderOffline();
}

search.addEventListener('input', () => {
  query = search.value;
  showFilters = false;
  renderMap();
});
search.addEventListener('keydown', event => {
  if (event.key !== 'Enter') return;
  const first = visible()[0];
  if (first && query.trim()) { search.blur(); openPlace(first.id, true); }
});

app.addEventListener('click', async event => {
  const node = (event.target as HTMLElement).closest<HTMLElement>('button,a');
  if (!node) return;
  if (node.hasAttribute('data-online') && !navigator.onLine) {
    event.preventDefault();
    flash('Для внешней карты или расписания нужен интернет.');
    return;
  }
  const data = node.dataset;
  if (data.view) { switchView(data.view as View); return; }
  if (data.day) {
    selectDay(data.day);
    filteredDay = false;
    renderPlan();
    content.querySelector<HTMLElement>('[data-day="' + data.day + '"]')?.focus({ preventScroll: true });
    setHash();
    return;
  }
  if (data.place) { openPlace(data.place, data.jump === 'true'); return; }
  if (data.addPlace) {
    const place = placeFor(data.addPlace);
    if (place) visitEditor.open(day.date, undefined, place);
    return;
  }
  if (data.editVisit) {
    const visit = local.visits.find(entry => entry.id === data.editVisit);
    if (visit) visitEditor.open(day.date, visit);
    return;
  }
  if (data.editPacking) {
    const item = local.packing.find(entry => entry.id === data.editPacking);
    if (item) {
      editingPacking = item.id;
      packingDraft = item.text;
      renderChecklist();
      $<HTMLInputElement>('#packing-text').select();
    }
    return;
  }
  if (data.removePacking) {
    const item = local.packing.find(entry => entry.id === data.removePacking);
    if (item && window.confirm('Убрать «' + item.text + '» из сборов?')) {
      local.packing = local.packing.filter(entry => entry.id !== item.id);
      delete local.checked[item.id];
      if (editingPacking === item.id) {
        editingPacking = undefined;
        packingDraft = '';
      }
      persist();
      renderChecklist();
      flash('Пункт убран.');
    }
    return;
  }
  if (data.packingSuggestion !== undefined) {
    const text = packingSuggestions[Number(data.packingSuggestion)];
    if (text && savePackingItem(text, undefined, false)) flash('Пункт добавлен в сборы.');
    return;
  }
  const completed = data.eventDone || data.visitDone;
  if (completed) {
    local.visited[completed] = !local.visited[completed];
    persist();
    if (view === 'plan') {
      renderPlan();
      app.querySelector<HTMLElement>('[data-visit-done="' + completed + '"],.event [data-event-done="' + completed + '"]')
        ?.focus({ preventScroll: true });
    }
    return;
  }
  if (data.visited) {
    local.visited[data.visited] = !local.visited[data.visited];
    persist();
    if (view === 'map') renderMap();
    const place = placeFor(data.visited);
    const offset = sheet.querySelector('.sheet-body')?.scrollTop ?? 0;
    if (place) showPlace(place, false);
    const body = sheet.querySelector('.sheet-body');
    if (body) body.scrollTop = offset;
    sheet.querySelector<HTMLElement>('[data-visited]')?.focus({ preventScroll: true });
    return;
  }
  switch (data.action) {
    case 'add-visit': visitEditor.open(day.date); break;
    case 'cancel-packing':
      editingPacking = undefined;
      packingDraft = '';
      renderChecklist();
      break;
    case 'cancel-pin': finishPicking(); break;
    case 'close': {
      selected = undefined;
      sheet.hidden = true;
      if (view === 'map') renderMap();
      setHash();
      break;
    }
    case 'area': area = area === 'seoul' ? 'trip' : 'seoul'; (await getMap())?.fit(area); renderMap(); break;
    case 'list': showList = !showList; showFilters = false; renderMap(); break;
    case 'filters': showFilters = !showFilters; showList = false; search.value = query = ''; renderMap(); break;
    case 'home': openPlace('hotel', Boolean(placeFor('hotel')?.coords)); break;
    case 'zoom-in': (await getMap())?.zoom(1); break;
    case 'zoom-out': (await getMap())?.zoom(-1); break;
    case 'locate': {
      if (!navigator.geolocation || !window.isSecureContext) { flash('Геолокация доступна при открытии по HTTPS.'); break; }
      flash('Определяем местоположение…');
      navigator.geolocation.getCurrentPosition(async ({ coords }) => {
        const map = await getMap();
        if (!map) return;
        const within = map.locate([coords.latitude, coords.longitude], coords.accuracy);
        flash(within ? 'Точность: около ' + Math.ceil(coords.accuracy) + ' м' : 'Ты за пределами карты поездки.');
      }, error => flash(error.code === 1 ? 'Доступ к геолокации не разрешён. Карта остаётся доступной.' : 'Не удалось определить местоположение.'), {
        enableHighAccuracy: true, timeout: 14000, maximumAge: 10000
      });
      break;
    }
    case 'copy': {
      const place = selected ? placeFor(selected) : undefined;
      const address = place?.addressKo || place?.addressLatin;
      if (!address) break;
      try { await navigator.clipboard.writeText(address); flash('Адрес скопирован.'); }
      catch {
        const field = document.createElement('textarea');
        field.value = address;
        field.style.cssText = 'position:fixed;top:0;left:0;opacity:0';
        document.body.append(field);
        field.select();
        const copied = document.execCommand('copy');
        field.remove();
        flash(copied ? 'Адрес скопирован.' : 'Нажми и удерживай текст адреса, чтобы скопировать его.');
      }
      break;
    }
    case 'download': {
      if (downloading) break;
      offlineError = '';
      if (!navigator.onLine) { offlineError = 'Подключись к интернету, чтобы скачать пакет.'; renderOffline(); break; }
      downloading = true;
      progress = 0;
      renderOffline();
      const previousVersion = installedPackage?.version;
      try {
        const savedVersion = await downloadOffline(percent => {
          progress = percent;
          const status = $('#offline-settings progress') as HTMLProgressElement | null;
          if (status) { status.value = percent; status.nextElementSibling!.textContent = percent + '%'; }
        });
        await verifyOffline();
        if (!installedPackage) throw new Error('Пакет скачался, но браузер не подтвердил сохранение всех файлов.');
        if (previousVersion && savedVersion !== previousVersion) {
          location.reload();
          return;
        }
        flash('Карта и программа готовы к офлайну.');
      } catch (error) {
        offlineError = error instanceof Error ? error.message : 'Не удалось скачать пакет.';
      } finally {
        downloading = false;
        renderOffline();
      }
      break;
    }
    case 'import': $('#import-file').click(); break;
    case 'export': {
      const url = URL.createObjectURL(new Blob([JSON.stringify({ version: 1, data: local }, null, 2)], { type: 'application/json' }));
      const link = document.createElement('a');
      link.download = 'seoul-trip-backup.json';
      link.href = url;
      document.body.append(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 5000);
      break;
    }
  }
});
app.addEventListener('change', async event => {
  const node = event.target as HTMLInputElement | HTMLSelectElement;
  if (node.id === 'map-date') {
    filteredDay = Boolean(node.value);
    if (node.value) selectDay(node.value);
    renderMap();
    $('#map-date').focus();
    return;
  }
  if (node.id === 'map-category') {
    category = node.value as typeof category;
    renderMap();
    $('#map-category').focus();
    return;
  }
  if (node.id === 'start-at-hotel') {
    local.startAtHotel = (node as HTMLInputElement).checked;
    persist();
    renderPlan();
    $('#start-at-hotel').focus({ preventScroll: true });
  }
  if (node.dataset.check) {
    local.checked[node.dataset.check] = (node as HTMLInputElement).checked;
    persist();
    renderChecklist();
    app.querySelector<HTMLElement>('[data-check="' + node.dataset.check + '"]')?.focus({ preventScroll: true });
  }
  if (node.dataset.move && dates.includes(node.value)) {
    local.moved[node.dataset.move] = node.value;
    persist();
    selectDay(node.value);
    renderPlan();
    setHash();
    flash('Перенесено на ' + short(node.value) + '.');
  }
  if (node.id === 'import-file') {
    const input = node as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;
    try {
      if (file.size > 1e6) throw new Error('Файл слишком большой для резервной копии.');
      const imported = parseBackup(JSON.parse(await file.text()));
      if (!window.confirm('Заменить настройки и отметки данными из этого файла?')) return;
      local = imported;
      persist();
      renderSettings();
      flash('Данные восстановлены.');
    } catch (error) { flash(error instanceof Error ? error.message : 'Не удалось прочитать JSON.'); }
    finally { input.value = ''; }
  }
});
app.addEventListener('input', event => {
  const node = event.target as HTMLInputElement;
  if (node.id === 'packing-text') packingDraft = node.value;
});
app.addEventListener('submit', event => {
  const target = event.target as HTMLFormElement;
  if (target.id === 'packing-form') {
    event.preventDefault();
    const value = String(new FormData(target).get('text') ?? '');
    const wasEditing = Boolean(editingPacking);
    if (savePackingItem(value, editingPacking)) {
      $('#packing-text').focus({ preventScroll: true });
      flash(wasEditing ? 'Пункт сохранён.' : 'Пункт добавлен в сборы.');
    }
    return;
  }
  if (target.id !== 'settings-form') return;
  event.preventDefault();
  const form = new FormData(target);
  const settings = Object.fromEntries(settingsFields.map(([key]) => [key, String(form.get(key) || '').trim()])) as Settings;
  if ((settings.lat || settings.lng) && !hotelCoords(settings)) {
    flash('Для отеля нужны обе координаты: широта от −90 до 90 и долгота от −180 до 180.');
    return;
  }
  local.settings = settings;
  persist();
  renderSettings();
  flash('Настройки сохранены.');
});
window.addEventListener('online', () => { lastUpdateCheck = 0; updateHeader(); void refreshOffline(); });
window.addEventListener('offline', () => { updateHeader(); flash('Без сети. Внешние карты и расписания требуют подключения.'); });
window.addEventListener('hashchange', () => {
  selected = undefined;
  sheet.hidden = true;
  readHash();
});
window.addEventListener('keydown', event => {
  if (event.key !== 'Escape' || $<HTMLDialogElement>('#visit-editor').open) return;
  if (picking) finishPicking();
  else if (!sheet.hidden) sheet.querySelector<HTMLButtonElement>('.close-sheet')?.click();
});
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) {
    if (view === 'plan' && !$<HTMLDialogElement>('#visit-editor').open) renderPlan();
    void refreshOffline();
  }
});
window.addEventListener('resize', () => { if (view === 'map') tripMap?.resize(); });
initOffline();
readHash();
void refreshOffline();

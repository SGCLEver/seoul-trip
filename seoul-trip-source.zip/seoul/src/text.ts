import type { Place } from './trip';

export function escape(value: string | number | undefined | null): string {
  return String(value ?? '').replace(/[&<>"']/g, char =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char] ?? char));
}
const normalize = (value: string) => value.normalize('NFKC').toLowerCase()
  .replaceAll('ё', 'е').replace(/[^\p{L}\p{N}]+/gu, ' ').trim();

export function matchesPlace(place: Place, query: string): boolean {
  const terms = normalize(query);
  if (!terms) return true;
  const text = normalize([place.name, place.ko, place.en, place.addressKo, place.addressLatin, ...(place.aliases ?? [])].join(' '));
  return terms.split(' ').every(term => text.includes(term));
}

export const short = (date: string) => date.slice(8) + '.' + date.slice(5, 7);

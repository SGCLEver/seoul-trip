import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { PMTiles } from 'pmtiles';
import { leafletLayer, PmtilesSource, TileCache, View } from 'protomaps-leaflet';
import archivePath from '../map-data/seoul.pmtiles?url';
import type { Coords, Place, Priority } from './trip';

const archiveUrl = new URL(archivePath, document.baseURI).href;
export const seoulBounds: L.LatLngBoundsExpression = [[37.494, 126.900], [37.587, 127.108]];
export const tripBounds: L.LatLngBoundsExpression = [[37.218, 126.41], [37.592, 127.145]];
const coverage = L.latLngBounds([[36.96, 126.14], [37.85, 127.43]]);
export type MapPlace = Place & { priority: Priority; visited: boolean; unavailable: boolean };

class ArchiveSource {
  private full?: Promise<Blob>;
  private ranges = true;
  getKey() { return archiveUrl; }
  async getBytes(offset: number, length: number, signal?: AbortSignal) {
    if (!this.full && this.ranges) {
      const response = await fetch(archiveUrl, { headers: { Range: `bytes=${offset}-${offset + length - 1}` }, signal });
      if (response.status === 206) return { data: await response.arrayBuffer() };
      if (response.status !== 200) throw new Error('Не удалось загрузить карту улиц');
      this.ranges = false;
      this.full = response.blob().catch(error => {
        this.full = undefined;
        this.ranges = true;
        throw error;
      });
    }
    if (!this.full) throw new Error('Не удалось прочитать карту улиц');
    const file = await this.full;
    return { data: await file.slice(offset, offset + length).arrayBuffer() };
  }
}

export class TripMap {
  private readonly map: L.Map;
  private readonly points = L.layerGroup();
  private readonly location = L.layerGroup();
  private selected = new Map<string, L.Marker>();
  private currentPlaces: MapPlace[] = [];
  private activeId?: string;
  private initialized = false;
  private lastLocation: Coords | null = null;
  private pickListener: (event: L.LeafletMouseEvent) => void = () => {};

  constructor(element: HTMLElement, private open: (ids: string[]) => void, onError: () => void) {
    this.map = L.map(element, {
      zoomControl: false, attributionControl: false, minZoom: 9, maxZoom: 18, zoomSnap: 0.25,
      maxBounds: coverage, maxBoundsViscosity: 0.85
    }).setView([37.5545, 126.998], 11.5);
    L.control.attribution({ position: 'bottomleft', prefix: false }).addTo(this.map);
    L.control.scale({ position: 'bottomright', imperial: false }).addTo(this.map);
    const archive = new PMTiles(new ArchiveSource());
    // The renderer reads from the same PMTiles package instance as this client.
    const layer = leafletLayer({
      url: archive, maxDataZoom: 14, maxZoom: 18, lang: 'en', flavor: 'light', noWrap: true,
      attribution: '© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> · Protomaps'
    });
    const detail = (layer.views as Map<string, View>).get('')!;
    // Higher-resolution tiles are stored only near Seoul and the stops.
    const cache = new TileCache(new PmtilesSource(archive, false), detail.tileCache.tileSize);
    detail.tileCache = cache;
    const lowerLevels = [13, 12, 10].map(zoom => new View(cache, zoom, detail.levelDiff));
    const detailedTile = detail.getDisplayTile.bind(detail);
    detail.getDisplayTile = async coords => {
      let tile = await detailedTile(coords);
      for (const lower of lowerLevels) {
        if (tile.data.size || tile.dataTile.z <= 10) break;
        if (lower.maxDataLevel < tile.dataTile.z) tile = await lower.getDisplayTile(coords);
      }
      return tile;
    };
    const base = layer as unknown as L.GridLayer;
    base.on('tileerror', onError);
    base.addTo(this.map);
    this.points.addTo(this.map);
    this.location.addTo(this.map);
    this.map.on('zoomend', () => this.drawPoints());
  }

  pick(callback?: (coords: Coords) => void) {
    this.map.off('click', this.pickListener);
    this.pickListener = event => callback?.([event.latlng.lat, event.latlng.lng]);
    if (callback) this.map.on('click', this.pickListener);
  }

  resize() {
    this.map.invalidateSize({ animate: false });
    if (!this.initialized) {
      this.initialized = true;
      this.fit('seoul');
    }
  }

  fit(area: 'seoul' | 'trip') {
    this.map.fitBounds(area === 'seoul' ? seoulBounds : tripBounds, {
      paddingTopLeft: [17, 100], paddingBottomRight: [17, 40],
      animate: false, maxZoom: area === 'seoul' ? 12.15 : 11
    });
  }

  zoom(increment: number) { this.map.setZoom(this.map.getZoom() + increment); }

  render(places: MapPlace[], selectedId?: string) {
    this.currentPlaces = places;
    this.activeId = selectedId;
    this.drawPoints();
  }

  private drawPoints() {
    this.points.clearLayers();
    this.selected.clear();
    const locs = new Map<string, MapPlace[]>();
    for (const place of this.currentPlaces) {
      if (!place.coords) continue;
      const key = place.coords.join(',');
      const group = locs.get(key) ?? [];
      group.push(place);
      locs.set(key, group);
    }
    const zoom = this.map.getZoom();
    const clusters: { anchor: L.Point; places: MapPlace[]; locations: Coords[]; active: boolean }[] = [];
    for (const entries of locs.values()) {
      const coords = entries[0].coords!;
      const anchor = this.map.project(coords, zoom);
      const active = entries.some(place => place.id === this.activeId);
      const adjacent = !active && zoom < 15
        ? clusters.find(cluster => !cluster.active && cluster.anchor.distanceTo(anchor) < 31)
        : undefined;
      if (adjacent) {
        adjacent.places.push(...entries);
        adjacent.locations.push(coords);
      } else {
        clusters.push({ anchor, places: entries, locations: [coords], active });
      }
    }
    for (const { places: group, locations, active: isActive } of clusters) {
      const lead = group.find(place => place.id === this.activeId) ?? group.find(place => !place.parent) ?? group[0];
      const clustered = locations.length > 1;
      const markerCoords = clustered ? L.latLngBounds(locations).getCenter() : lead.coords!;
      const classes = ['pin', 'pin-' + lead.priority, clustered ? 'pin-cluster' : '', lead.unavailable ? 'pin-closed' : '',
        isActive ? 'pin-active' : '', lead.visited ? 'pin-visited' : ''].join(' ');
      const label = clustered ? `${group.length} мест рядом. Открыть список.` : group.map(place => place.name).join(' / ');
      const badge = group.length > 1 && !clustered ? `<span class="pin-count">${group.length}</span>` : '';
      const core = clustered ? String(group.length) : '<span class="pin-core"></span>';
      const marker = L.marker(markerCoords, {
        title: label, alt: label,
        icon: L.divIcon({
          className: classes, html: `<span class="pin-shape">${core}</span>${badge}`,
          iconSize: [38, 38], iconAnchor: [19, 19]
        }),
        keyboard: true, zIndexOffset: isActive ? 1000 : 0
      }).on('click', () => this.open(group.map(place => place.id)));
      marker.addTo(this.points);
      marker.getElement()?.setAttribute('aria-label', label);
      for (const place of group) this.selected.set(place.id, marker);
    }
  }

  focus(place: Place, coveredHeight = 0) {
    if (!place.coords) return;
    this.resize();
    this.map.setView(place.coords, Math.max(this.map.getZoom(), 15.5), { animate: false });
    if (coveredHeight) {
      const mapHeight = this.map.getSize().y;
      const visibleHeight = mapHeight - coveredHeight;
      const target = Math.max(90, (Math.min(108, visibleHeight) + visibleHeight) / 2);
      this.map.panBy([0, Math.max(0, mapHeight / 2 - target)], { animate: false });
    }
    const element = this.selected.get(place.id)?.getElement();
    element?.classList.add('pin-active');
  }

  locate(coords: Coords, accuracy: number) {
    this.lastLocation = coords;
    this.location.clearLayers();
    L.circle(coords, { radius: accuracy, color: '#0877cc', weight: 1, fillOpacity: 0.14 }).addTo(this.location);
    L.circleMarker(coords, { radius: 8, color: 'white', weight: 3, fillColor: '#0877cc', fillOpacity: 1 })
      .bindTooltip('Ты здесь').addTo(this.location);
    const within = coverage.contains(coords);
    if (within) this.map.setView(coords, 15.5, { animate: false });
    return within;
  }

  get userLocation() { return this.lastLocation; }
}

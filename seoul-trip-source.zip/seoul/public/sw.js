const scope = new URL(self.registration.scope);
const prefix = 'seoul-offline:' + scope.pathname + ':';
const sharedName = 'seoul-maps:' + scope.pathname;
const url = path => new URL(path, scope);
const indexUrl = url('offline-index.json');
const readyUrl = url('offline-ready');
const archiveFiles = new Map();
let downloading;
let listeners = [];
let lastPercent = -1;

self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));

async function readyStores() {
  const names = (await caches.keys()).filter(name => name.startsWith(prefix)).reverse();
  const entries = await Promise.all(names.map(async name => {
    const store = await caches.open(name);
    return await store.match(readyUrl) ? { name, store } : undefined;
  }));
  return entries.filter(Boolean);
}

async function reuseAsset(path, older) {
  if (!path.pathname.startsWith(url('assets/').pathname)) return undefined;
  for (const { store } of older) {
    const entry = await store.match(path);
    if (entry) return entry;
  }
}

async function downloadFile(path, asset, onBytes) {
  const file = await fetch(path, { cache: 'reload' });
  if (!file.ok || file.status !== 200) throw new Error('Скачивание прервалось. Повтори попытку при подключении к интернету.');
  const reader = file.body?.getReader();
  if (!reader) return file;
  let received = 0;
  const body = new ReadableStream({
    async pull(controller) {
      try {
        const { done, value } = await reader.read();
        if (done) {
          if (received !== asset.bytes && !file.headers.has('Content-Encoding')) {
            controller.error(new Error('Файл загрузился не полностью.'));
          } else controller.close();
          return;
        }
        received += value.byteLength;
        onBytes(received);
        controller.enqueue(value);
      } catch (error) { controller.error(error); }
    },
    cancel(reason) { return reader.cancel(reason); }
  });
  const headers = new Headers(file.headers);
  headers.delete('Content-Encoding');
  headers.delete('Content-Length');
  return new Response(body, { headers });
}

function progress(bytes, total) {
  const percent = Math.min(99, Math.round(bytes / total * 100));
  if (percent === lastPercent) return;
  lastPercent = percent;
  for (const port of listeners) port.postMessage({ type: 'progress', percent });
}

async function cleanOldVersions(keep) {
  const names = await caches.keys();
  const shared = await caches.open(sharedName);
  const referenced = new Set();
  for (const name of keep) {
    const store = await caches.open(name);
    const index = await (await store.match(indexUrl))?.json();
    for (const asset of index?.assets ?? []) if (asset.shared) referenced.add(url(asset.path).href);
  }
  await Promise.all(names.filter(name => name.startsWith(prefix) && !keep.includes(name)).map(name => caches.delete(name)));
  for (const request of await shared.keys()) {
    if (referenced.has(request.url)) continue;
    archiveFiles.delete(request.url);
    await shared.delete(request);
  }
}

async function storePackage() {
  const response = await fetch(indexUrl, { cache: 'no-store' });
  if (!response.ok) throw new Error('Не удалось получить список файлов. Проверь подключение.');
  const index = await response.clone().json();
  const name = prefix + index.version;
  const older = (await readyStores()).filter(entry => entry.name !== name);
  const store = await caches.open(name);
  const shared = await caches.open(sharedName);
  let complete = 0;
  for (const asset of index.assets) {
    const path = url(asset.path);
    const target = asset.shared ? shared : store;
    if (!await target.match(path)) {
      const file = await reuseAsset(path, older)
        ?? await downloadFile(path, asset, received => progress(complete + received, index.bytes));
      await target.put(path, file);
    }
    complete += asset.bytes;
    progress(complete, index.bytes);
  }
  await store.put(indexUrl, response);
  await store.put(readyUrl, new Response(index.version));
  // Keep the previous shell while any open page might still need one of its chunks.
  await cleanOldVersions([name, ...older.slice(0, 1).map(entry => entry.name)]).catch(() => {});
  return index.version;
}

self.addEventListener('message', event => {
  const port = event.ports[0];
  if (event.data?.type !== 'download' || !port) return;
  listeners.push(port);
  if (lastPercent > -1) port.postMessage({ type: 'progress', percent: lastPercent });
  downloading ??= storePackage().then(
    version => listeners.forEach(listener => listener.postMessage({ type: 'ready', version })),
    error => listeners.forEach(listener => listener.postMessage({
      type: 'error',
      message: error.name === 'QuotaExceededError' || /quota|space/i.test(error.message)
        ? 'На устройстве не хватает места. Освободи место и повтори загрузку.'
        : error.message || 'Не удалось сохранить офлайн-пакет.'
    }))
  ).finally(() => {
    for (const listener of listeners) listener.close();
    listeners = [];
    downloading = undefined;
    lastPercent = -1;
  });
  event.waitUntil(downloading);
});

async function cachedRange(address, response, range) {
  let blob = archiveFiles.get(address.href);
  if (!blob) {
    blob = response.blob().catch(error => {
      archiveFiles.delete(address.href);
      throw error;
    });
    if (archiveFiles.size >= 2) archiveFiles.delete(archiveFiles.keys().next().value);
    archiveFiles.set(address.href, blob);
  }
  const file = await blob;
  const match = /^bytes=(\d+)-(\d*)$/.exec(range);
  const start = Number(match?.[1]);
  const end = Math.min(match?.[2] ? Number(match[2]) : file.size - 1, file.size - 1);
  if (!match || start >= file.size || end < start) {
    return new Response(null, { status: 416, headers: { 'Content-Range': 'bytes */' + file.size } });
  }
  const part = file.slice(start, end + 1);
  return new Response(part, { status: 206, headers: {
    'Content-Range': `bytes ${start}-${end}/${file.size}`,
    'Content-Length': String(part.size),
    'Content-Type': 'application/octet-stream',
    'Accept-Ranges': 'bytes'
  } });
}

self.addEventListener('fetch', event => {
  const request = event.request;
  const address = new URL(request.url);
  if (request.method !== 'GET' || address.origin !== scope.origin || !address.pathname.startsWith(scope.pathname)) return;
  if (address.pathname === indexUrl.pathname && address.searchParams.has('remote')) return;
  event.respondWith((async () => {
    const isArchive = address.pathname.endsWith('.pmtiles');
    const range = request.headers.get('Range');
    if (isArchive && await caches.has(sharedName)) {
      const local = await (await caches.open(sharedName)).match(address);
      if (local) return range ? cachedRange(address, local, range) : local;
    }
    const isPage = request.mode === 'navigate';
    const target = isPage ? url('index.html') : request;
    for (const { store } of await readyStores()) {
      const local = await store.match(target);
      if (local) return isArchive && range ? cachedRange(address, local, range) : local;
    }
    try {
      return await fetch(request);
    } catch (error) {
      if (!isPage) throw error;
      return new Response('Открой приложение с интернетом и скачай карту для офлайна.', {
        status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' }
      });
    }
  })());
});
